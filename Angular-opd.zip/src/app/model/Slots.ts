export class Slots {
  public startTime: string;
  public endTime: string;
  constructor() {}
}
