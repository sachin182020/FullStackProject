import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-appointment',
  templateUrl: './cancel-appointment.component.html',
  styleUrls: ['./cancel-appointment.component.css']
})
export class CancelAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
